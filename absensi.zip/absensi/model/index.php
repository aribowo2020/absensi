<?php
    /**
     * 
     *  Absensi Siswa Prakerin
     *  codinger-mini.blogpsot.com
     *  fb.me/rizal.ofdraw
     *  
     */
	echo "<script>window.alert('Waaahh.. Bandel ya !! ');window.location=('../home');</script>"; 
?>